# Open and Free Datasets and Models by Salute Developers


## [Golos dataset](https://github.com/salute-developers/golos/tree/master/golos#golos-dataset) 
Russian corpus suitable for speech research.

## [Dusha dataset](https://github.com/salute-developers/golos/tree/master/dusha#dusha-dataset)
Bi-modal corpus suitable for speech emotion recognition tasks.


## **License**

[English Version](https://github.com/salute-developers/golos/blob/master/license/en_us.pdf)

[Russian Version](https://github.com/salute-developers/golos/blob/master/license/ru.pdf)